install.packages("haven")
install.packages("tidyverse")
install.packages("sjmisc")
install.packages("sjlabelled")
install.packages("srvyr")
# for R version =< 3.4.3
install.packages("tidytab")
# for R version > 3.4.3
install.packages("devtools") # Restart session - Y
devtools::install_github("gvelasq/tidytab") 
#For Windows users check if needed: https://www.r-project.org/nosvn/pandoc/devtools.html
